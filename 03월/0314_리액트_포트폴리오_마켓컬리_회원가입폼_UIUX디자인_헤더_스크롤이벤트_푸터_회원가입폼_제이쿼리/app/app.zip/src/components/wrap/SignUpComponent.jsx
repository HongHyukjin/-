import React from 'react';

export default function SignUpComponent (){
  return (
    <div id='signUp'>
      <h1>SignUp component</h1>
    </div>
  );
};

