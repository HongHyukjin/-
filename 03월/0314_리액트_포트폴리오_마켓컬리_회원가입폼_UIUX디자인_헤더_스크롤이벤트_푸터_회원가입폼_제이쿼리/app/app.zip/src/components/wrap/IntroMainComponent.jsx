import React from 'react';

const IntroMainComponent = () => {
  return (
    <div className='sub-page intro'>
      <h1>IntroMainComponent</h1>
    </div>
  );
};

export default IntroMainComponent;