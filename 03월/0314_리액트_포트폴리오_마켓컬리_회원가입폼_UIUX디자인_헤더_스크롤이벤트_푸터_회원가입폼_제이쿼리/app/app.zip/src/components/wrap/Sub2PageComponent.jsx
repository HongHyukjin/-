import React from 'react';

const Sub2PageComponent = () => {
  return (
    <div className='sub-page sub2'>
      <h1>고객센터</h1>
    </div>
  );
};

export default Sub2PageComponent;