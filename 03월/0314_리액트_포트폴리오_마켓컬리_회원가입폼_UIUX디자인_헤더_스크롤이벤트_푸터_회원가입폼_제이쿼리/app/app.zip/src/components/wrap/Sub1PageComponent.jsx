import React from 'react';

const Sub1PageComponent = () => {
  return (
    <div className='sub-page sub1'>
      <h1>로그인</h1>
    </div>
  );
};

export default Sub1PageComponent;