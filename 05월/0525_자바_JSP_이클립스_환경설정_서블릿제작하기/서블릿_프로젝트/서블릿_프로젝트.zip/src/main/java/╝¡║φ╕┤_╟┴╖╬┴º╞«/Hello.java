package 서블릿_프로젝트;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요! JAVA 파일입니다.");	   
	}

}
